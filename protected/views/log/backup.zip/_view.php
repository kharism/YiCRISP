<div class="view">
<span class="span4"><?php echo $data->date;?></span>
<span class="span4"><?php echo $data->User->username;?></span>
<span class="span4">
	<ul>
<?php 
	$stat = CJSON::decode($data->value);
	//$key = array_keys($stat)
	foreach($stat as $key=>$value):?>
	<li><?echo $key.":".$value;?></li>
	<?php
	endforeach;
?>
</ul>
</span>

</div>
