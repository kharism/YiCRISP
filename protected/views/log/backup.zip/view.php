<?php

?>
<h1>View Log <?php echo $_GET['model']." ".$_GET["model_id"]; ?></h1>
<?php 
$dp = new CArrayDataProvider($logs);
$this->widget("zii.widgets.CListView",array(
	"dataProvider"=>$dp,
	"itemView"=>"_view",
	)
);
