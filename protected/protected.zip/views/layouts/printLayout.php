<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Fluid Bootstrap, from Twitter</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <style type="text/css">
            .breakHere{
                page-break-after: always
            }
        </style>
    </head>
    <body>
        <?php echo $content ?>
    </body>
</html>