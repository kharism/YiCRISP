<?php echo $page->content; ?>
