<div style="background-color:#ccc;margin:0 10px;">
    
    <i>subsection: <?php echo __FILE__; ?></i> 

    <p><?php echo $page->content; ?></p>

</div>