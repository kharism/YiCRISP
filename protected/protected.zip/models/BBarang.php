<?php
class BBarang extends CFormModel{
	
}
